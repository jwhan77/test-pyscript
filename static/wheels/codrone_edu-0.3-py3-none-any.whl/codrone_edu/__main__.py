import sys
from codrone_edu.tools.parser import *


if __name__ == '__main__':

    parser = Parser()

    parser.run()
